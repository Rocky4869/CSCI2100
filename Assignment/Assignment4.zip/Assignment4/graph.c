/* graph.c */
#include "graph.h"
#include "list.h"
#include <stdbool.h>
#include <math.h>
#include <stdlib.h>

#define MAX_N 100 /* Possible nodes are node 0, node 1, ..., node 99. */

struct GraphCDT{
    float W[MAX_N*(MAX_N+1)/2];
    bool NodeExists[MAX_N];
};

GraphADT EmptyGraph(void){
    GraphADT G;
    G = (GraphADT) malloc(sizeof(*G));
    for(int i=0; i<MAX_N; i++) G->NodeExists[i] = false;            //All nodes are preassigned as not exist
    for(int i=0; i<MAX_N*(MAX_N+1)/2; i++) G->W[i] = INFINITY;  //All arcs are preassigned to inf(no weight)
    return G;
}
bool GraphIsEmpty(GraphADT G){
    for(int i=0; i<MAX_N; i++)
        if(NodeExists(G, i)) return false;
    return true;
}

void AddNode(GraphADT G, Node n){               //Need debug ************
    if(!NodeExists(G, n))
        G->NodeExists[n] = true;
}

void DeleteNode(GraphADT G, Node n){               //Need debug ************
    if(!NodeExists(G, n))
        G->NodeExists[n] = false;
}

bool NodeExists(GraphADT G, Node n){
    return G->NodeExists[n];
}


void AddArc(GraphADT G, Node i, Node j, float x){
    if(i>j){
        int temp=j;
        j=i; i=temp;
    }
    if(!NodeExists(G, i)||!NodeExists(G, j)){
        exit(EXIT_FAILURE);
    }
    G->W[j+i*MAX_N-i*(i+1)/2] = x;
}

void DeleteArc(GraphADT G, Node i, Node j){
    G->W[j+i*MAX_N-i*(i+1)/2] = 0;
    if(!NodeExists(G, i)||!NodeExists(G, j)){
        exit(EXIT_FAILURE);
    }
}


float ArcWeight(GraphADT G, Node i, Node j){
    if(!ArcExists(G, i, j)){
        exit(EXIT_FAILURE);
    }
    return G->W[ArctoIndex(G, i, j)];
}

bool ArcExists(GraphADT G, Node i, Node j){
    if(i>j){
        int temp=j;
        j=i; i=temp;
    }
    if(i==j){
        exit(EXIT_FAILURE);
    }
    if(G->W[j+i*MAX_N-i*(i+1)/2]==INFINITY)
        return false;
    return true;
}

listADT AdjList(GraphADT G, Node n){
    listADT list = EmptyList();
    for(int i=MAX_N-1; i>=0; i--){
        if(i!=n){
            if(ArcExists(G, n, i)){
                list = Cons(i, list);
            }
        }
    }
    return list;
}

void PrintAllNodes(GraphADT G){
    if(GraphIsEmpty(G)){
        printf("(PrintAllNodes)Graph is empty");
        exit(EXIT_FAILURE);
    }
    for(int i=0; i<MAX_N; i++)
        if(NodeExists(G, i))
            printf("%d\n", i);
}

void PrintAllArcs(GraphADT G){
    if(GraphIsEmpty(G)){
        exit(EXIT_FAILURE);
    }
    for(int i=0; i<MAX_N; i++){
        for(int j=i+1; j<MAX_N; j++){
            if(ArcExists(G, i, j))
                printf("(%d,%d) %d\n", i, j, (int)G->W[ArctoIndex(G, i, j)]);
        }
    }
}

int ArctoIndex(GraphADT G, Node i, Node j){
    if(!ArcExists(G, i, j)){
        exit(EXIT_FAILURE);
    }
    return j+i*MAX_N-i*(i+1)/2;
}
void IndextoArcNodes(GraphADT G, int x, Node* i, Node* j){
    int m=1;int n;
    int x1; while(x>= (x1=m*MAX_N-m*(m-1)/2))m++;
    m--;n=MAX_N+x-x1;
    (*i)=m;(*j)=n;
    /* The arc is (m,n), or ((*i),(*j))--whether the arc exists is not checked! */
}