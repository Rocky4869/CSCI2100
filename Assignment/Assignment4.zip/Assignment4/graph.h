/* graph.h */
#include "list.h"
#include <stdbool.h>
#include <math.h>
typedef struct GraphCDT * GraphADT;
typedef int Node;
GraphADT EmptyGraph(void); /* returns an empty undirected graph */
bool GraphIsEmpty(GraphADT); /* returns whether graph is empty */
void AddNode(GraphADT, Node); /* add a node */
void DeleteNode(GraphADT, Node); /* delete a node */
bool NodeExists(GraphADT, Node); /* returns whether the node exists */
listADT AllNodes(GraphADT); /* returns a list of all nodes in the graph */
void AddArc(GraphADT, Node, Node, float);
/* add an arc */
/* note that the last argument is the weight */
void DeleteArc(GraphADT, Node, Node); /* delete an arc */
float ArcWeight(GraphADT, Node, Node); /* returns the weight of an arc, possibly INFINITY */
bool ArcExists(GraphADT, Node, Node); /* returns whether the arc exists */
listADT AdjList(GraphADT, Node); /* returns a list of adjacent nodes of a node */
void PrintAllNodes(GraphADT); /* prints all existing nodes */
void PrintAllArcs(GraphADT); /* prints all existing arcs */
int ArctoIndex(GraphADT, Node, Node); /* see below */
void IndextoArcNodes(GraphADT, int, Node*, Node*);
/* see below */