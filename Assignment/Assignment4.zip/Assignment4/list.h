#ifndef lists_h
#define lists_h

#include <stdio.h>

typedef struct listCDT *listADT;

typedef int listElementT;

//Secrion 1 : Basic Function
listADT EmptyList(void);
listADT Cons(listElementT, listADT);
listElementT Head(listADT);
listADT Tail(listADT);
int ListIsEmpty(listADT);

#endif /* lists_h */
