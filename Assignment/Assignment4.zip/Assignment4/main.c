#include <stdio.h>
#include "graph.h"
#include <stdlib.h>

int main(int argc, const char * argv[]) {

    GraphADT G = EmptyGraph();
    char c[1000];
    FILE *fptr;
    if ((fptr = fopen("GraphData.dat", "r")) == NULL) {
        printf("Error! File cannot be opened.\n");
        exit(EXIT_FAILURE);
    }

    fptr = fopen("GraphData.dat", "r");


    while(!feof(fptr)){
        char data[1000]; int j=0;
        fgets(c, "%s", fptr);
        for(int i=0; i<100; i++){
            if(c[i]!=' '){
                data[j] = c[i];
                j++;
            }
        }

        //assign the data to graph
        if(data[0]=='n')
            AddNode(G, data[1]-48);
        else
            AddArc(G, data[1]-48, data[2]-48, data[3]-48);
    }

    fclose(fptr);

    PrintAllNodes(G);
    PrintAllArcs(G);

    return 0;
}