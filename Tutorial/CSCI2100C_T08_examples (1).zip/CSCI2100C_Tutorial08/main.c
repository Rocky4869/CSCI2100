#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main() {
    //  pointer to the file
    FILE *studentData;
    //  open a file in read only mode
    //  'r': read only; 'w': write only; 'a': read+write
    studentData = fopen("E:\\Projects\\CSCI2100C_Tutorial08\\studentData.txt", "r");
    //  check whether the file exists or not
    if (studentData == NULL) {
        printf("File %s not existed or read failure.\n", "studentData.txt");
        exit(EXIT_FAILURE);
    }
    // The following lines of code read and output each line of the file.
    char line[50];  // Please make sure that the length of the array is larger than the length of the longest line.
    //  fgets function receives three parameters,
    while(fgets(line, sizeof(line), studentData) != NULL) {
        printf("%s", line);
    }
    return 0;
}
