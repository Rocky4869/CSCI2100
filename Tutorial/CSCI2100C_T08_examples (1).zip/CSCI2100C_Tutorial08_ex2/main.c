#include <stdio.h>
#include <stdlib.h>

int add_pbv(int x, int y) {
    y = y + x;
    return y;
}

int add_pbr(int x, int* pt) {
    *pt = *pt + x;
    return *pt;
}

void arrayWrite(int position, int val, int* arr) {
    arr[position] = val;
}

int main() {
    int x = 1;
    int y = 2;

    add_pbv(x, y);
    printf("Pass by value: y = %d\n", y);

    add_pbr(x, &y);
    printf("Pass by reference: y = %d\n", y);

    int* arr = (int*)malloc(5 * sizeof(int));
    for (int i = 0; i<5;i++){
        arr[i] = 0;
    }
    printf("arr[2] = %d\n", arr[2]);

    arrayWrite(2, 1, arr);
    printf("arr[2] = %d\n", arr[2]);

    return 0;
}
